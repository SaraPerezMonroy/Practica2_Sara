using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Suelo : MonoBehaviour
{
    [SerializeField]
    Material sueloVerde;
    [SerializeField]
    Material sueloRojo;



    // Start is called before the first frame update
    void Start()
    {
        gameObject.GetComponent<MeshRenderer>().material = sueloVerde;
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "Player")
        {
            gameObject.GetComponent<MeshRenderer>().material = sueloRojo;
            Invoke("Destruye", 3f); // Esta funci�n permite hacer una invocaci�n de m�todos para que ocurran en un momento determinado.

        }
    }
    private void Destruye()
    {
        Destroy(gameObject);
    }

}
