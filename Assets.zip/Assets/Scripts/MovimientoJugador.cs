using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovimientoJugador : MonoBehaviour
{

    public float velocidadMovimiento = 8f;
    public float salto = 30f;
    private AudioSource audioSource;


    [SerializeField]
    GameObject pantallaDerrota;


    // Start is called before the first frame update
    void Start()
    {
        transform.Translate(2f, 0f, -2f);
        audioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        float movimientoEjeX = Input.GetAxis("Horizontal") * velocidadMovimiento * Time.deltaTime;
        float movimientoEjeY = Input.GetAxis("Vertical") * velocidadMovimiento * Time.deltaTime;
        float movimientoEjeZ = Input.GetAxis("Jump") * salto * Time.deltaTime;


        // Mueve el jugador
        Vector3 movimiento = new Vector3(movimientoEjeX, movimientoEjeZ, movimientoEjeY);
        transform.Translate(movimiento);

        Physics.gravity = new Vector3(0, -9f, 0);

        if (gameObject.transform.position.y < -3.5f)
        {
            Time.timeScale = 0;
            pantallaDerrota.SetActive(true);
            }
    }

        void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Coin"))
            {
                if (audioSource != null)
                {
                   audioSource.Play();
                }

            }

    }
}
