using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CoinCounter : MonoBehaviour
{
    public static CoinCounter instance;

    // Para las monedas que consigue el jugador
    public TMP_Text coinText;
    public int currentCoins = 0;

    // Variable para rastrear la cantidad total de monedas conseguidas
    private int totalCoins = 0;
    
    
    private AudioSource audioSource;


    // Tiempo de partida y detener movimiento
    float tiempoDePartida = 0.0f;
    bool estaJugando = true;

    [SerializeField]
    GameObject pantallaFinal;

    [SerializeField]
    TextMeshProUGUI textLabelTime;


    void Awake()
    {
        // Las monedas que tiene en el momento
        instance = this;
    }


    void Start()
    {
        coinText.text = "x " + currentCoins.ToString("00");
        audioSource = GetComponent<AudioSource>();

    }


    void Update()
    {
        if (estaJugando == true)
        {
            tiempoDePartida = tiempoDePartida + Time.deltaTime;
        }  
        
        if (totalCoins == 9)
            {
               pantallaFinal.SetActive(true);
               Time.timeScale = 0;
               textLabelTime.text = tiempoDePartida.ToString("0.0") + " segundos";
                CoinCounter coinCounter = FindObjectOfType<CoinCounter>();
                int totalCoins = coinCounter.GetTotalCoins();        
                audioSource.Stop();

            }
        
    }


    public void IncreaseCoins(int cantidad)
    {
        currentCoins += cantidad;
        totalCoins += cantidad; // Aumentar la cantidad total
        coinText.text = "x " + currentCoins.ToString("00"); // Con esto se va ense�ando las monedas que se van ganando
    }


    // M�todo para obtener la cantidad total de monedas
    public int GetTotalCoins()
    {
        return totalCoins;
    }

 
}
